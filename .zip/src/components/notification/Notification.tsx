import React from "react";

const Notification = () => {
  return (
    <div className="fixed z-10 w-full h-screen blur-3xl h-hull p-64">
      12312323123
    </div>
  );
};

export default Notification;
